#include <stdio.h>

int main()
{

    int arr[100];
    int n, i;
    scanf("%d",&n);
    for(i = 0; i<n; i++)
        scanf("%d", arr[i]);
    return 0;
}

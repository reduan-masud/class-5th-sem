#include <stdio.h>

int main()
{

    int arr[100];
    while(scanf("%d", &arr[i]) != EOF)
    {

    }

    return 0;
}

